package proyecto1;

/**
* It represents a Directed Graph, it models the social network
*/
public class DirGraph {
    LinkedList<User> users;
   
    public DirGraph(){
         this.users = new LinkedList<>();
    }
   
    public boolean addUser(String name) {
        // Check if user is already in the list
        Node<User> current = users.head;
        while (current != null) {
            if (current.data.name.equals(name)) {
                return false; // Element found in the list
            }
            current = current.next;
        }
        
        // Add user to list
        User newUser = new User(name);
        users.append(newUser);
        System.out.println(name);
        return true;
    }
    
    public boolean deleteUser(String name) {
        // Check if user is in list
        Node<User> current = users.head;
        while (current != null) {
            if (current.data.name.equals(name)) {
                users.delete(current.data);
                return true; // Element found in the list
            }
            current = current.next;
        }
        return false;
    }

    public boolean addFriend(String source, String destination) {
        User sourceUser = null;
        User destUser = null;

        // Find source and destination vertices
        for (int i=0; i< users.size; i++) {
            User current = users.get(i);
            if (current.name.equals(source)) {
                sourceUser = current;
            }
            else if (current.name.equals(destination)) {
                destUser = current;
            }
        }

        if (sourceUser != null && destUser != null) {
            // Check if destUser is in friends list
            Node<User> current = sourceUser.friends.head;
            while (current != null) {
                if (current.data.name.equals(destUser.name)) {
                    return false; // Element found in the list
                }
                current = current.next;
            }
        
            sourceUser.friends.append(destUser);
            System.out.println(sourceUser.name + " " + destUser.name);            
            return true;
        } else {
            System.out.println("Invalid edge.");
            return false;
        }
    }  
}
