package proyecto1;
import java.io.FileWriter;
import java.io.IOException;

/**
* It represents a Directed Graph, it models the social network
*/
public class DirGraph {
    LinkedList<User> users;
   
    public DirGraph(){
        this.users = new LinkedList<>();
    }
   
    // Add a new user to the graph
    public boolean addUser(String name) {
        // Check if user is already in the list
        NodeT<User> current = users.head;
        while (current != null) {
            if (current.data.name.equals(name)) {
                return false; // Element found in the list
            }
            current = current.next;
        }
        
        // Add user to list
        User newUser = new User(name);
        users.append(newUser);
        return true;
    }
    
    // Deletes a user from the graph
    public boolean deleteUser(String name) {
        // Check if user is in list
        NodeT<User> current = users.head;
        while (current != null) {
            if (current.data.name.equals(name)) {
                // Delete user from users list
                users.delete(current.data);
                
                // Delete user from friendships
                current = users.head;
                while (current != null) {
                    NodeT<User> friend = current.data.friends.head;
                    while(friend != null){
                        if(friend.data.name.equals(name)){
                            current.data.friends.delete(friend.data);
                        }
                        friend = friend.next;
                    }
                    current = current.next;
                }
            
                return true; // Element found in the list
            }
            current = current.next;
        }
        return false;
    }
    
    // Deletes a frienship to the graph
    public boolean addFriend(String source, String destination) {
        User sourceUser = null;
        User destUser = null;

        // Find source and destination nodes
        for (int i=0; i< users.size; i++) {
            User current = users.get(i);
            if (current.name.equals(source)) {
                sourceUser = current;
            }
            else if (current.name.equals(destination)) {
                destUser = current;
            }
        }

        if (sourceUser != null && destUser != null) {
            // Check if destUser is in friends list
            NodeT<User> current = sourceUser.friends.head;
            while (current != null) {
                if (current.data.name.equals(destUser.name)) {
                    return false; // Element found in the list
                }
                current = current.next;
            }
        
            sourceUser.friends.append(destUser);           
            return true;
        } else {
            System.out.println("Invalid edge.");
            return false;
        }
    }  
    
    // Get the index of a node given its name
    int getIndex(String name){
        if(users.head == null) 
            return -1;
        if(users.head.data.name.equals(name))
            return 0;
        int index = 1;
        NodeT<User> current = users.head.next;
        while (current != null) {
            if(current.data.name.equals(name)){
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }
    
    // Get a Node from a Graph (it can be the transpose) given the name of the user
    NodeT<User> getNode(String name, LinkedList<User> list){
        NodeT<User> current = list.head;
        while (current != null) {
            if(current.data.name.equals(name)){
               return current;
            }
            current = current.next;
        }
        return null;
    }
    
    // Makes the DFS and adds the visited nodes to a list
    void DFS(int v, boolean[] visited, LinkedList<Integer> stack) {
        visited[v] = true;
        User current = users.get(v);
        
        int n = current.friends.size;
        for(int j = 0; j < n; j++){
            String friend = current.friends.get(j).name;
            int friendIndex = getIndex(friend);
            
            if (!visited[friendIndex])
                DFS(friendIndex, visited, stack);
        }
        
        stack.append(v);
    }
    
    // Makes the DFS of the transposes graph and returns a string with the visited nodes
    private String DFSTranpose(LinkedList<User> grafoTranspuesto, int v, boolean[] visited) {
        visited[v] = true;
        User current = grafoTranspuesto.get(v);
        
        int n = current.friends.size;
        for(int j = 0; j < n; j++){
            String friend = current.friends.get(j).name;
            int friendIndex = getIndex(friend);
            
            if (!visited[friendIndex])
                return Integer.toString(v) + " " + DFSTranpose(grafoTranspuesto, friendIndex, visited);
        }
        
        return Integer.toString(v);
    }
    
    // Find all the strong connected componentes (SCC) in the graph, and returns them in a string
    public String findSCC(){
        String components = "";
        LinkedList<Integer> stack = new LinkedList<>();

        int n = users.size;
        boolean[] visited = new boolean[n];
        for (int i = 0; i < n; i++) {
            visited[i] = false;
        }
        // Make the DFS of the normal graph
        for (int i = 0; i < n; i++) {
            if (!visited[i])
                DFS(i, visited, stack);
        }
        
        // Create transposed graph
        LinkedList<User> grafoTranspuesto = new LinkedList<>();
        NodeT<User> current = users.head;
        while (current != null) {
            User userCopy = new User(current.data.name);
            grafoTranspuesto.append(userCopy);
            current = current.next;
        }
        
        current = users.head;
        while (current != null) {
            NodeT<User> friend = current.data.friends.head;
            while(friend != null){
                NodeT<User> friendT = getNode(friend.data.name, grafoTranspuesto);
                friendT.data.friends.append(current.data);
                friend = friend.next;
            }
            current = current.next;
        }

            
        for (int i = 0; i < n; i++) {
            visited[i] = false;
        }
        
        // Make the DFS from the transposed graph
        while (n  > 0) {
            int v = stack.get(n-1);
            if (!visited[v]) {
                String scc = DFSTranpose(grafoTranspuesto, v, visited);
                components += scc + "\n";
            }
            stack.delete(v);
            n--;
        }
        
        return components;
    }
    
    // Write nodes and relationship in file
    public void saveInFile(String filename){
        try{
            FileWriter myWriter = new FileWriter(filename);
            myWriter.write("usuarios\n");
            NodeT<User> current = users.head;
            while (current != null) {
                myWriter.write(current.data.name + "\n");
                current = current.next;
            }
            
            myWriter.write("relaciones\n");
            current = users.head;
            while (current != null) {
                NodeT<User> friend = current.data.friends.head;
                while(friend != null){
                    myWriter.write(current.data.name+ ", " + friend.data.name + "\n");
                    friend = friend.next;
                }
                current = current.next;
            }
            
            myWriter.close();
        } catch (IOException f) {
          f.printStackTrace();
        } 
        
    }
}
