package proyecto1;

/**
* It represents a Node of type T
*/
public class NodeT<T> {
    T data;
    NodeT<T> next;

    public NodeT(T data){
        this.data = data;
        this.next = null;
    }
}
