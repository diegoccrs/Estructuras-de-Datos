package proyecto1;

public class Dirgraph {
    LinkedList<User> users;
   
    public Dirgraph(){
         this.users = new LinkedList<>();
    }
   
    public void addVertex(String name) {
        User newUser = new User(name);
        users.append(newUser);
    }

    public void addEdge(String source, String destination) {
        User sourceUser = null;
        User destUser = null;

        // Find source and destination vertices
        for (int i=0; i< users.size; i++) {
            User current = users.get(i);
            if (current.name.equals(source)) {
                sourceUser = current;
            }
            else if (current.name.equals(destination)) {
                destUser = current;
            }
        }

        if (sourceUser != null && destUser != null) {
            sourceUser.friends.append(destUser);
        } else {
            System.out.println("Invalid edge.");
        }
    }  
}
