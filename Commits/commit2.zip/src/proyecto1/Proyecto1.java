package proyecto1;

public class Proyecto1 {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
