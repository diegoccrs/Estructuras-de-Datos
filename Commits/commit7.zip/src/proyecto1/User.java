package proyecto1;

/**
* It represents a User in the social network, each one has a list of friends (Users)
*/
public class User {
   String name;
   LinkedList<User> friends;
   
   public User(String name) {
        this.name = name;
        this.friends = new LinkedList<>();
    }
}
