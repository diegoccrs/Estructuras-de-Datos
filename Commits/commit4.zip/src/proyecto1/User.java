package proyecto1;

public class User {
   String name;
   LinkedList<User> friends;
   
   public User(String name) {
        this.name = name;
        this.friends = new LinkedList<>();
    }
}
