package proyecto1;

public class Dirgraph {
    LinkedList<User> users;
   
    public Dirgraph(){
         this.users = new LinkedList<>();
    }
   
    public boolean addUser(String name) {
        // Check if user is already in the list
        Node<User> current = users.head;
        while (current != null) {
            if (current.data.name.equals(name)) {
                return false; // Element found in the list
            }
            current = current.next;
        }
        
        // Add user to list
        User newUser = new User(name);
        users.append(newUser);
        System.out.println(name);
        return true;
    }
    
    public boolean deleteUser(String name) {
        // Check if user is in lisr
        Node<User> current = users.head;
        while (current != null) {
            if (current.data.name.equals(name)) {
                users.delete(current.data);
                return true; // Element found in the list
            }
            current = current.next;
        }
        return false;
    }

    public void addFriend(String source, String destination) {
        User sourceUser = null;
        User destUser = null;

        // Find source and destination vertices
        for (int i=0; i< users.size; i++) {
            User current = users.get(i);
            if (current.name.equals(source)) {
                sourceUser = current;
            }
            else if (current.name.equals(destination)) {
                destUser = current;
            }
        }

        if (sourceUser != null && destUser != null) {
            sourceUser.friends.append(destUser);
            System.out.print(sourceUser);
            System.out.print(" ");
            System.out.println(sourceUser);
        } else {
            System.out.println("Invalid edge.");
        }
    }  
}
